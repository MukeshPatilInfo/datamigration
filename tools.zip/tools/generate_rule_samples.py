"""Create labeled, rule-prioritized sample CSVs from the three QA extracts."""

from __future__ import annotations

import bisect
import csv
import sys
from collections import defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "test-data" / "rule-samples"
SAMPLE_COUNT = 10

ENOVIA_HEADER = [
    "uuid", "type", "part_type", "object_id", "part_number", "revision",
    "description", "state", "eol", "project", "modified", "cad_primary",
    "cad_secondary", "latest_release_rev", "latest_rev", "last_revision",
    "last_enovia_dash", "last_enovia_dash_rev", "last_enovia_dash_state",
    "last_enovia_dash_modified",
]
EPDM_HEADER = [
    "uuid", "enovia_part_number", "description", "file_name", "creator",
    "creation_date", "cad_primary", "enovia_revision",
]
PDMLINK_HEADER = [
    "epm_doc_number", "enovia_part_number", "file_title_description",
    "file_name", "created_by", "designer", "creation_date", "cad_primary",
    "enovia_revision", "version", "iteration",
]

RULES = [
    ("Rule 1", "Exact duplicate across vaults"),
    ("Rule 2", "PDMLink file-name exact duplicate"),
    ("Rule 3", "PDMLink base-file-name exact duplicate"),
    ("Rule 4", "PDMLink base-file-name prefix duplicate"),
    ("Rule 5", "Exact PDM-to-ENOVIA match"),
    ("Rule 6", "PDM parameter prefix match"),
    ("Rule 7", "PDMLink file-name exact ENOVIA match"),
    ("Rule 8", "PDMLink file-name prefix ENOVIA match"),
    ("Rule 9", "PDMLink base-file-name exact ENOVIA match"),
    ("Rule 10", "PDMLink base-file-name prefix ENOVIA match"),
    ("Rule 11", "Normalized-description probable match"),
    ("Rule 12", "Part-number-only probable match"),
    ("Rule 13", "PDMLink file-name prefix duplicate"),
    ("Rule 14", "PDMLink base-file-name exact duplicate"),
    ("Rule 15", "PDMLink base-file-name prefix duplicate"),
]


def parse_line(raw: str) -> tuple[list[str], str | None]:
    fields: list[str] = []
    field: list[str] = []
    quoted = False
    field_started = False
    index = 0
    while index < len(raw):
        char = raw[index]
        if char == '"':
            if not field_started:
                quoted = True
                field_started = True
            elif quoted and index + 1 < len(raw) and raw[index + 1] == '"':
                field.append(char)
                index += 1
            elif quoted:
                quoted = False
            else:
                return fields, "Unexpected quote"
        elif char == "," and not quoted:
            fields.append("".join(field))
            field = []
            field_started = False
        else:
            field.append(char)
            field_started = True
        index += 1
    if quoted:
        return fields, "Unterminated quoted field"
    fields.append("".join(field))
    return fields, None


def load_rows(path: Path, columns: int, has_header: bool) -> list[list[str]]:
    rows: list[list[str]] = []
    with path.open(encoding="utf-8", newline="") as source:
        for line_number, raw in enumerate(source, start=1):
            if has_header and line_number == 1:
                continue
            row, error = parse_line(raw.rstrip("\r\n"))
            if error is None and len(row) == columns:
                rows.append(row)
    return rows


def clean(value: str) -> str:
    return value.strip()


def normalized(value: str) -> str:
    return clean(value).upper()


def normalized_description(value: str) -> str:
    return "".join(char for char in normalized(value) if char.isalnum())


def usable(value: str) -> bool:
    return bool(clean(value)) and normalized(value) != "NONE"


def file_stem(name: str) -> str:
    name = clean(name)
    dot = name.rfind(".")
    return name[:dot] if dot > 0 else name


def before_last_underscore(value: str) -> str:
    underscore = value.rfind("_")
    return value[:underscore] if underscore > 0 else value


def is_pdmlink(record: tuple[str, list[str]]) -> bool:
    return record[0] == "PDMLink"


def parameter_part(record: tuple[str, list[str]]) -> str:
    return record[1][1]


def description(record: tuple[str, list[str]]) -> str:
    return record[1][2]


def default_part(record: tuple[str, list[str]]) -> str:
    row = record[1]
    return row[1] if usable(row[1]) else file_stem(row[3])


def file_part(record: tuple[str, list[str]]) -> str:
    return file_stem(record[1][3]) if is_pdmlink(record) and not usable(parameter_part(record)) else ""


def base_part(record: tuple[str, list[str]]) -> str:
    return before_last_underscore(file_part(record))


def part_matches(candidate: str, target: str, prefix: bool) -> bool:
    candidate = normalized(candidate)
    target = normalized(target)
    return usable(candidate) and (target.startswith(candidate) if prefix else candidate == target)


def prefix_values(index: dict[str, list[int]], candidate: str) -> list[int]:
    candidate = normalized(candidate)
    keys = index["keys"]
    start = bisect.bisect_left(keys, candidate)
    end = bisect.bisect_left(keys, candidate + chr(0x10FFFF))
    result: list[int] = []
    for key in keys[start:end]:
        result.extend(index["values"][key])
    return result


def make_prefix_index(groups: dict[str, list[int]]) -> dict[str, object]:
    return {"keys": sorted(groups), "values": groups}


def label(rule: tuple[str, str]) -> str:
    return f"{rule[0]} - {rule[1]}"


def main() -> None:
    enovia = load_rows(ROOT / "dm_enovia_qa.csv", 20, False)
    epdm = load_rows(ROOT / "dm_epdm_qa.csv", 8, False)
    pdmlink = load_rows(ROOT / "dm_pdm_link_qa.csv", 11, True)
    pdm: list[tuple[str, list[str]]] = [("EPDM", row) for row in epdm]
    pdm.extend(("PDMLink", row) for row in pdmlink)
    latest_enovia = [row for row in enovia if normalized(row[14]) in {"YES", "Y", "TRUE", "1"}]

    pdm_exact: dict[tuple[str, str], list[int]] = defaultdict(list)
    pdm_prefix_groups: dict[str, dict[str, list[int]]] = defaultdict(lambda: defaultdict(list))
    for index, record in enumerate(pdm):
        pdm_exact[(normalized(default_part(record)), normalized(description(record)))].append(index)
        pdm_prefix_groups[normalized(description(record))][normalized(default_part(record))].append(index)
    pdm_prefix = {key: make_prefix_index(value) for key, value in pdm_prefix_groups.items()}

    enovia_exact_description: dict[str, list[int]] = defaultdict(list)
    enovia_normalized_description: dict[str, list[int]] = defaultdict(list)
    enovia_part_groups: dict[str, list[int]] = defaultdict(list)
    enovia_by_part: dict[str, list[int]] = defaultdict(list)
    for index, row in enumerate(latest_enovia):
        enovia_exact_description[normalized(row[6])].append(index)
        enovia_normalized_description[normalized_description(row[6])].append(index)
        enovia_part_groups[normalized(row[4])].append(index)
    for index, row in enumerate(enovia):
        enovia_by_part[normalized(row[4])].append(index)
    enovia_part_prefix = make_prefix_index(enovia_part_groups)

    matched: set[int] = set()
    pdm_labels: dict[int, str] = {}
    enovia_labels: dict[int, set[str]] = defaultdict(set)
    supporting_pdm: set[int] = set()
    selected_counts: dict[str, int] = {}

    def add_selection(rule: tuple[str, str], record_index: int, enovia_index: int | None = None,
                      duplicate_index: int | None = None) -> None:
        rule_id = rule[0]
        if selected_counts.get(rule_id, 0) >= SAMPLE_COUNT:
            return
        pdm_labels[record_index] = label(rule)
        selected_counts[rule_id] = selected_counts.get(rule_id, 0) + 1
        if enovia_index is not None:
            enovia_labels[enovia_index].add(label(rule))
        if duplicate_index is not None:
            supporting_pdm.add(duplicate_index)
        # Duplicate reports require ENOVIA project/EOL context when the part exists.
        if duplicate_index is not None:
            matching_enovia = enovia_by_part.get(normalized(default_part(pdm[record_index])), [])
            if matching_enovia:
                enovia_labels[matching_enovia[0]].add(label(rule))

    def duplicate_rule(rule: tuple[str, str], candidate_function, prefix: bool) -> None:
        newly_matched: list[tuple[int, int]] = []
        for record_index, record in enumerate(pdm):
            if record_index in matched:
                continue
            candidate = candidate_function(record)
            if not usable(candidate):
                continue
            if prefix:
                candidates = prefix_values(pdm_prefix.get(normalized(description(record)), {"keys": [], "values": {}}), candidate)
            else:
                candidates = pdm_exact.get((normalized(candidate), normalized(description(record))), [])
            other = next((item for item in candidates if item != record_index and
                         part_matches(candidate, default_part(pdm[item]), prefix)), None)
            if other is not None:
                newly_matched.append((record_index, other))
        for record_index, other in newly_matched:
            matched.add(record_index)
            add_selection(rule, record_index, duplicate_index=other)

    def enovia_rule(rule: tuple[str, str], candidate_function, prefix: bool, description_mode: str) -> None:
        newly_matched: list[tuple[int, int]] = []
        for record_index, record in enumerate(pdm):
            if record_index in matched:
                continue
            candidate = candidate_function(record)
            if not usable(candidate):
                continue
            if description_mode == "ignore":
                candidates = prefix_values(enovia_part_prefix, candidate)
            elif description_mode == "exact":
                candidates = enovia_exact_description.get(normalized(description(record)), [])
            else:
                candidates = enovia_normalized_description.get(normalized_description(description(record)), [])
            target = next((item for item in candidates if part_matches(candidate, latest_enovia[item][4], prefix)), None)
            if target is not None:
                newly_matched.append((record_index, target))
        for record_index, target in newly_matched:
            matched.add(record_index)
            add_selection(rule, record_index, target)

    duplicate_rule(RULES[0], default_part, False)
    duplicate_rule(RULES[1], file_part, False)
    duplicate_rule(RULES[2], base_part, False)
    duplicate_rule(RULES[3], base_part, True)
    enovia_rule(RULES[4], default_part, False, "exact")
    enovia_rule(RULES[5], parameter_part, True, "exact")
    enovia_rule(RULES[6], file_part, False, "exact")
    enovia_rule(RULES[7], file_part, True, "exact")
    enovia_rule(RULES[8], base_part, False, "exact")
    enovia_rule(RULES[9], base_part, True, "exact")
    enovia_rule(RULES[10], default_part, True, "normalized")
    enovia_rule(RULES[11], default_part, True, "ignore")
    duplicate_rule(RULES[12], file_part, True)
    duplicate_rule(RULES[13], base_part, False)
    duplicate_rule(RULES[14], base_part, True)

    missing = [rule[0] for rule in RULES if selected_counts.get(rule[0], 0) < SAMPLE_COUNT]
    if missing:
        print(", ".join(f"{rule[0]}={selected_counts.get(rule[0], 0)}" for rule in RULES))
        raise RuntimeError(f"Fewer than {SAMPLE_COUNT} samples found for: {', '.join(missing)}")

    OUTPUT.mkdir(parents=True, exist_ok=True)
    selected_pdm = set(pdm_labels) | supporting_pdm
    with (OUTPUT / "dm_epdm_qa_rule_samples.csv").open("w", newline="", encoding="utf-8") as destination:
        writer = csv.writer(destination)
        writer.writerow([*EPDM_HEADER, "expected_rule_id_name"])
        for index, record in enumerate(pdm):
            if index in selected_pdm and record[0] == "EPDM":
                writer.writerow([*record[1], pdm_labels.get(index, "Supporting duplicate record")])
    with (OUTPUT / "dm_pdm_link_qa_rule_samples.csv").open("w", newline="", encoding="utf-8") as destination:
        writer = csv.writer(destination)
        writer.writerow([*PDMLINK_HEADER, "expected_rule_id_name"])
        for index, record in enumerate(pdm):
            if index in selected_pdm and record[0] == "PDMLink":
                writer.writerow([*record[1], pdm_labels.get(index, "Supporting duplicate record")])
    with (OUTPUT / "dm_enovia_qa_rule_samples.csv").open("w", newline="", encoding="utf-8") as destination:
        writer = csv.writer(destination)
        writer.writerow([*ENOVIA_HEADER, "supports_expected_rule_id_name"])
        for index, row in enumerate(enovia):
            if index in enovia_labels:
                writer.writerow([*row, " | ".join(sorted(enovia_labels[index]))])

    summary = OUTPUT / "sample-summary.csv"
    with summary.open("w", newline="", encoding="utf-8") as destination:
        writer = csv.writer(destination)
        writer.writerow(["rule_id", "rule_name", "labeled_pdm_records"])
        for rule in RULES:
            writer.writerow([rule[0], rule[1], selected_counts[rule[0]]])
    print(f"Created labeled sample CSVs in {OUTPUT}")


if __name__ == "__main__":
    main()
