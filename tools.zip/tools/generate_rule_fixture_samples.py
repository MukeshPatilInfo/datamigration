"""Generate rule-isolated test fixtures using metadata from the supplied QA extracts."""

from __future__ import annotations

import csv
from pathlib import Path

from generate_rule_samples import (
    ENOVIA_HEADER,
    EPDM_HEADER,
    OUTPUT,
    PDMLINK_HEADER,
    RULES,
    ROOT,
    load_rows,
)

SAMPLES_PER_RULE = 10


def rule_label(rule_number: int) -> str:
    rule = RULES[rule_number - 1]
    return f"{rule[0]} - {rule[1]}"


def write_csv(path: Path, header: list[str], rows: list[list[str]]) -> None:
    with path.open("w", newline="", encoding="utf-8") as destination:
        writer = csv.writer(destination)
        writer.writerow([*header, "expected_rule_id_name"])
        writer.writerows(rows)


def main() -> None:
    epdm_source = load_rows(ROOT / "dm_epdm_qa.csv", 8, False)
    pdmlink_source = load_rows(ROOT / "dm_pdm_link_qa.csv", 11, True)
    enovia_source = load_rows(ROOT / "dm_enovia_qa.csv", 20, False)
    epdm_rows: list[list[str]] = []
    pdmlink_rows: list[list[str]] = []
    enovia_rows: list[list[str]] = []
    epdm_cursor = pdmlink_cursor = enovia_cursor = 0

    def epdm(rule: int, part: str, description: str, filename: str) -> None:
        nonlocal epdm_cursor
        row = epdm_source[epdm_cursor % len(epdm_source)].copy()
        epdm_cursor += 1
        row[1], row[2], row[3] = part, description, filename
        epdm_rows.append([*row, rule_label(rule)])

    def pdmlink(rule: int, part: str, description: str, filename: str) -> None:
        nonlocal pdmlink_cursor
        row = pdmlink_source[pdmlink_cursor % len(pdmlink_source)].copy()
        pdmlink_cursor += 1
        row[1], row[2], row[3] = part, description, filename
        pdmlink_rows.append([*row, rule_label(rule)])

    def enovia(rule: int, part: str, description: str) -> None:
        nonlocal enovia_cursor
        row = enovia_source[enovia_cursor % len(enovia_source)].copy()
        enovia_cursor += 1
        row[4], row[6], row[14] = part, description, "YES"
        enovia_rows.append([*row, rule_label(rule)])

    for item in range(1, SAMPLES_PER_RULE + 1):
        key = f"TEST-R01-{item:03}"
        description = f"Rule 1 duplicate sample {item}"
        epdm(1, key, description, f"{key}.SLDPRT")
        pdmlink(1, key, description, f"{key}.PRT")
        enovia(1, key, description)

        key = f"TEST-R02-{item:03}"
        description = f"Rule 2 duplicate sample {item}"
        pdmlink(2, "NONE", description, f"{key}.PRT")
        pdmlink(2, "NONE", description, f"{key}.ASM")
        enovia(2, key, description)

        key = f"TEST-R03-{item:03}"
        description = f"Rule 3 duplicate sample {item}"
        pdmlink(3, "NONE", description, f"{key}_A.PRT")
        pdmlink(3, "NONE", description, f"{key}_B.PRT")
        enovia(3, key, description)

        key = f"TEST-R04-{item:03}"
        description = f"Rule 4 duplicate sample {item}"
        pdmlink(4, "NONE", description, f"{key}_A_1.PRT")
        pdmlink(4, "NONE", description, f"{key}_A2_1.PRT")
        enovia(4, key, description)

        key = f"TEST-R05-{item:03}"
        description = f"Rule 5 exact match sample {item}"
        epdm(5, key, description, f"{key}.SLDPRT")
        enovia(5, key, description)

        key = f"TEST-R06-{item:03}"
        description = f"Rule 6 prefix match sample {item}"
        epdm(6, key, description, f"{key}.SLDPRT")
        enovia(6, f"{key}-ENOVIA", description)

        key = f"TEST-R07-{item:03}"
        description = f"Rule 7 file-name exact sample {item}"
        pdmlink(7, "NONE", description, f"{key}.PRT")
        enovia(7, key, description)

        key = f"TEST-R08-{item:03}"
        description = f"Rule 8 file-name prefix sample {item}"
        pdmlink(8, "NONE", description, f"{key}.PRT")
        enovia(8, f"{key}-ENOVIA", description)

        key = f"TEST-R09-{item:03}"
        description = f"Rule 9 base-file-name exact sample {item}"
        pdmlink(9, "NONE", description, f"{key}_A.PRT")
        enovia(9, key, description)

        key = f"TEST-R10-{item:03}"
        description = f"Rule 10 base-file-name prefix sample {item}"
        pdmlink(10, "NONE", description, f"{key}_A.PRT")
        enovia(10, f"{key}-ENOVIA", description)

        key = f"TEST-R11-{item:03}"
        pdm_description = f"Rule 11 probable-description sample {item}!"
        enovia_description = f"Rule11 probable description sample {item}"
        epdm(11, key, pdm_description, f"{key}.SLDPRT")
        enovia(11, f"{key}-ENOVIA", enovia_description)

        key = f"TEST-R12-{item:03}"
        epdm(12, key, f"Rule 12 PDM description {item}", f"{key}.SLDPRT")
        enovia(12, f"{key}-ENOVIA", f"Unrelated ENOVIA description {item}")

        key = f"TEST-R13-{item:03}"
        description = f"Rule 13 duplicate sample {item}"
        pdmlink(13, "NONE", description, f"{key}-A.PRT")
        pdmlink(13, "NONE", description, f"{key}-AB.PRT")
        enovia(13, key, description)

        key = f"TEST-R14-{item:03}"
        description = f"Rule 14 duplicate sample {item}"
        pdmlink(14, "NONE", description, f"{key}_A.PRT")
        pdmlink(14, "NONE", description, f"{key}_B.PRT")
        enovia(14, key, description)

        key = f"TEST-R15-{item:03}"
        description = f"Rule 15 duplicate sample {item}"
        pdmlink(15, "NONE", description, f"{key}_A_1.PRT")
        pdmlink(15, "NONE", description, f"{key}_A2_1.PRT")
        enovia(15, key, description)

    OUTPUT.mkdir(parents=True, exist_ok=True)
    write_csv(OUTPUT / "dm_epdm_qa_rule_samples.csv", EPDM_HEADER, epdm_rows)
    write_csv(OUTPUT / "dm_pdm_link_qa_rule_samples.csv", PDMLINK_HEADER, pdmlink_rows)
    write_csv(OUTPUT / "dm_enovia_qa_rule_samples.csv", ENOVIA_HEADER, enovia_rows)

    with (OUTPUT / "sample-summary.csv").open("w", newline="", encoding="utf-8") as destination:
        writer = csv.writer(destination)
        writer.writerow(["rule_id", "rule_name", "primary_pdm_cases"])
        for rule, name in RULES:
            writer.writerow([rule, name, SAMPLES_PER_RULE])
    print(f"Created rule-isolated fixtures in {OUTPUT}")


if __name__ == "__main__":
    main()
