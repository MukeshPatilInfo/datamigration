# Data Migration Rule Unit Test Plan

## Scope and test data

The three `*_rule_samples.csv` files contain ten primary PDM cases for every Rule 1 through
Rule 15. Their final `expected_rule_id_name` column identifies the rule and expected outcome.
PDM duplicate rules include a labeled counterpart record, and every rule includes the
corresponding labeled ENOVIA context row. Test identifiers start with `TEST-Rnn-`.

The supplied extracts have insufficient naturally eligible records for many later rules once the
required earlier-rule exclusions are applied. Therefore these are **rule-isolated fixtures**:
their non-matching metadata and vault values were taken from the supplied QA extracts, while test
part numbers, descriptions, and file names are deterministic values constructed to exercise the
specified predicate. They must not be treated as production records.

Load only the rows labeled for one rule at a time, along with every row carrying that same label
from the other component CSVs. This prevents an earlier rule from intentionally consuming a case
that is designed to test a later rule in isolation.

## Common validation

For every case:

1. Load the filtered EPDM, PDMLink, and ENOVIA rows into an empty test database.
2. Clear `dm_data_match_rules` and the output report directory.
3. Execute the rule under test.
4. Assert that each of the ten primary PDM cases appears once in the expected report and once in
   `dm_data_match_rules` with the expected `matched_rule` and `pdm_vault`.
5. Assert that no record with another `TEST-Rnn-` prefix is written and that every output CSV
   parses successfully with its configured header.

## Rule test cases

| Rule | Fixture predicate | Expected result |
| --- | --- | --- |
| Rule 1 | Exact PDM part number and description duplicate | 10 duplicate report matches |
| Rule 2 | PDMLink blank/NONE parameter; exact file stem and description duplicate | 10 duplicate report matches |
| Rule 3 | PDMLink blank/NONE parameter; exact stem-before-last-underscore and description duplicate | 10 duplicate report matches |
| Rule 4 | PDMLink base file part is a prefix of another base file part; descriptions equal | 10 duplicate report matches |
| Rule 5 | Exact PDM parameter part number and description equals ENOVIA | 10 Load Sheet 1 matches |
| Rule 6 | PDM parameter is an ENOVIA part-number prefix; descriptions equal | 10 Report 3 matches |
| Rule 7 | PDMLink file stem and description exactly equal ENOVIA | 10 Load Sheet 2 matches |
| Rule 8 | PDMLink file stem is an ENOVIA part-number prefix; descriptions equal | 10 Report 4 matches |
| Rule 9 | PDMLink stem-before-last-underscore and description exactly equal ENOVIA | 10 Report 5 matches |
| Rule 10 | PDMLink base file part is an ENOVIA part-number prefix; descriptions equal | 10 Report 6 matches |
| Rule 11 | Part prefix and description match after case, spaces, and special characters are normalized | 10 Report 7 matches |
| Rule 12 | Part-number prefix match with deliberately different descriptions | 10 Report 8 matches |
| Rule 13 | PDMLink file stem prefix duplicate with equal descriptions | 10 Report 9 matches |
| Rule 14 | PDMLink base file part exact duplicate with equal descriptions | 10 Report 10 matches |
| Rule 15 | PDMLink base file part prefix duplicate with equal descriptions | 10 Report 11 matches |

## Data accuracy and completeness checks

- Confirm each file has its canonical source columns plus exactly one final expected-rule column.
- Confirm `sample-summary.csv` lists 15 rules and 10 primary PDM cases for each.
- Confirm all PDM vaults remain values from the corresponding supplied QA extract.
- Confirm every ENOVIA fixture has `latest_rev=YES`; the application must not match non-latest
  ENOVIA records.
- Confirm duplicate fixture pairs share their required normalized description and matching key.
- Confirm Rule 11 descriptions differ only by normalization, while Rule 12 descriptions remain
  deliberately different.
- Confirm processing order separately with an integration test: once a PDM UUID is recorded in
  `dm_data_match_rules`, it must be excluded from every later rule and report.
