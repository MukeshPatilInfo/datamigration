"""Execute the 15 data-migration matching rules defined in DM_Analysis_Rules_v1.0.xlsx."""

from __future__ import annotations

import csv
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

import psycopg
from psycopg import sql


@dataclass(frozen=True)
class PdmRecord:
    uuid: str
    parameter_part: str
    description: str
    file_name: str
    creator: str
    creation_date: str
    vault: str
    revision: str
    source: str
    pdm_link: bool

    @property
    def default_part(self) -> str:
        return self.parameter_part if usable(self.parameter_part) else file_stem(self.file_name)


@dataclass(frozen=True)
class EnoviaRecord:
    uuid: str
    type: str
    part_number: str
    revision: str
    description: str
    cad_primary: str
    project: str
    eol: str
    object_id: str
    latest_release_revision: str
    latest_revision: str
    state: str
    last_dash: str
    cad_secondary: str


@dataclass(frozen=True)
class ReportRow:
    pdm: PdmRecord
    enovia: EnoviaRecord | None
    matched_vaults: str


@dataclass(frozen=True)
class Settings:
    db_url: str
    db_user: str
    db_password: str
    enovia_table: str
    epdm_table: str
    pdm_link_table: str
    match_table: str
    report_directory: Path
    duplicate_columns: list[str]
    match_columns: list[str]

    @classmethod
    def load(cls, path: Path) -> Settings:
        values: dict[str, str] = {}
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                key, separator, value = line.partition("=")
                if not separator:
                    raise ValueError(f"Invalid configuration line: {line}")
                values[key.strip()] = value.strip()

        def required(key: str) -> str:
            value = values.get(key, "")
            if not value:
                raise ValueError(f"Missing required setting: {key}")
            return value

        def table(key: str) -> str:
            value = required(key)
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
                raise ValueError(f"Invalid SQL identifier in {key}")
            return value

        def columns(key: str) -> list[str]:
            return [column.strip() for column in required(key).split(",")]

        return cls(
            required("db.url"),
            required("db.user"),
            required("db.password"),
            table("table.enovia"),
            table("table.epdm"),
            table("table.pdmLink"),
            table("table.matches"),
            Path(required("reports.directory")),
            columns("report.columns.duplicate"),
            columns("report.columns.match"),
        )


class DataMigrationAnalysisUtility:
    """Runs each spreadsheet rule in order and excludes previously matched PDM UUIDs."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def execute_all_rules(self, connection: psycopg.Connection) -> None:
        pdm_records = self._load_pdm_records(connection)
        enovia_records = self._load_latest_enovia_records(connection)
        self.rule1(connection, pdm_records, enovia_records)
        self.rule2(connection, pdm_records, enovia_records)
        self.rule3(connection, pdm_records, enovia_records)
        self.rule4(connection, pdm_records, enovia_records)
        self.rule5(connection, pdm_records, enovia_records)
        self.rule6(connection, pdm_records, enovia_records)
        self.rule7(connection, pdm_records, enovia_records)
        self.rule8(connection, pdm_records, enovia_records)
        self.rule9(connection, pdm_records, enovia_records)
        self.rule10(connection, pdm_records, enovia_records)
        self.rule11(connection, pdm_records, enovia_records)
        self.rule12(connection, pdm_records, enovia_records)
        self.rule13(connection, pdm_records, enovia_records)
        self.rule14(connection, pdm_records, enovia_records)
        self.rule15(connection, pdm_records, enovia_records)

    # Rule 1: exact part number and exact description duplicates across vaults.
    def rule1(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 1", "report-1-duplicates", pdm,
                             lambda record: record.default_part, "exact")

    # Rule 2: PDMLink blank part number, filename part and exact description duplicates.
    def rule2(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 2", "report-2-duplicates", pdm,
                             self._pdm_link_file_part, "exact")

    # Rule 3: PDMLink filename before the last underscore and exact description duplicates.
    def rule3(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 3", "report-10-duplicates", pdm,
                             self._pdm_link_base_part, "exact")

    # Rule 4: PDMLink filename base prefix and exact description duplicates.
    def rule4(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 4", "report-11-duplicates", pdm,
                             self._pdm_link_base_part, "prefix")

    # Rule 5: exact PDM part number and description match against ENOVIA.
    def rule5(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 5", "load-sheet-1", pdm, enovia,
                          lambda record: record.default_part, "exact", "exact")

    # Rule 6: PDM parameter prefix and exact description match against ENOVIA.
    def rule6(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 6", "report-3", pdm, enovia,
                          lambda record: record.parameter_part, "prefix", "exact")

    # Rule 7: PDMLink filename part and exact description match against ENOVIA.
    def rule7(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 7", "load-sheet-2", pdm, enovia,
                          self._pdm_link_file_part, "exact", "exact")

    # Rule 8: PDMLink filename part prefix and exact description match against ENOVIA.
    def rule8(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 8", "report-4", pdm, enovia,
                          self._pdm_link_file_part, "prefix", "exact")

    # Rule 9: PDMLink filename base and exact description match against ENOVIA.
    def rule9(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 9", "report-5", pdm, enovia,
                          self._pdm_link_base_part, "exact", "exact")

    # Rule 10: PDMLink filename base prefix and exact description match against ENOVIA.
    def rule10(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 10", "report-6", pdm, enovia,
                          self._pdm_link_base_part, "prefix", "exact")

    # Rule 11: wildcard part number with normalized probable-description matching.
    def rule11(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 11", "report-7", pdm, enovia,
                          lambda record: record.default_part, "prefix", "normalized")

    # Rule 12: wildcard part number only, without a description condition.
    def rule12(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 12", "report-8", pdm, enovia,
                          lambda record: record.default_part, "prefix", "ignore")

    # Rule 13: PDMLink filename wildcard duplicates across vaults.
    def rule13(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 13", "report-9-duplicates", pdm,
                             self._pdm_link_file_part, "prefix")

    # Rule 14: PDMLink filename base exact duplicates across vaults.
    def rule14(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 14", "report-10-duplicates", pdm,
                             self._pdm_link_base_part, "exact")

    # Rule 15: PDMLink filename base wildcard duplicates across vaults.
    def rule15(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 15", "report-11-duplicates", pdm,
                             self._pdm_link_base_part, "prefix")

    def _duplicate_rule(self, connection, rule: str, report: str, all_records: list[PdmRecord],
                        part: Callable[[PdmRecord], str], match: str) -> None:
        rows: list[ReportRow] = []
        for record in self._unmatched(connection, all_records):
            candidate = part(record)
            if not usable(candidate):
                continue
            vaults = {
                other.vault for other in all_records
                if other.uuid != record.uuid
                and part_matches(candidate, other.default_part, match)
                and descriptions_match(record.description, other.description, "exact")
            }
            if vaults:
                rows.append(ReportRow(record, None, "|".join(sorted(vaults))))
        self._persist_and_write(connection, rule, report, rows, self.settings.duplicate_columns)

    def _enovia_rule(self, connection, rule: str, report: str, all_records: list[PdmRecord],
                     enovia_records: list[EnoviaRecord], part: Callable[[PdmRecord], str],
                     match: str, description: str) -> None:
        rows: list[ReportRow] = []
        for record in self._unmatched(connection, all_records):
            candidate = part(record)
            if not usable(candidate):
                continue
            for target in enovia_records:
                if (part_matches(candidate, target.part_number, match)
                        and descriptions_match(record.description, target.description, description)):
                    rows.append(ReportRow(record, target, ""))
        self._persist_and_write(connection, rule, report, rows, self.settings.match_columns)

    def _persist_and_write(self, connection, rule: str, report: str, candidates: list[ReportRow],
                           columns: list[str]) -> None:
        first_match = {row.pdm.uuid: row for row in candidates}
        inserted_uuids: set[str] = set()
        query = sql.SQL(
            "INSERT INTO {} (uuid, matched_rule, pdm_vault) "
            "SELECT %s, %s, %s WHERE NOT EXISTS (SELECT 1 FROM {} WHERE uuid = %s)"
        ).format(sql.Identifier(self.settings.match_table), sql.Identifier(self.settings.match_table))
        with connection.cursor() as cursor:
            for row in first_match.values():
                cursor.execute(query, (row.pdm.uuid, rule, row.pdm.vault, row.pdm.uuid))
                if cursor.rowcount == 1:
                    inserted_uuids.add(row.pdm.uuid)
        self._write_report(rule, report, columns,
                           (row for row in candidates if row.pdm.uuid in inserted_uuids))

    def _unmatched(self, connection, records: list[PdmRecord]) -> list[PdmRecord]:
        query = sql.SQL("SELECT uuid FROM {}").format(sql.Identifier(self.settings.match_table))
        with connection.cursor() as cursor:
            cursor.execute(query)
            matched = {str(row[0]) for row in cursor}
        return [record for record in records if record.uuid not in matched]

    def _load_pdm_records(self, connection) -> list[PdmRecord]:
        records: list[PdmRecord] = []
        self._load_pdm(connection, self.settings.epdm_table, "EPDM", False,
                       "uuid, enovia_part_number, description, file_name, creator, creation_date, cad_primary, enovia_revision",
                       records)
        self._load_pdm(connection, self.settings.pdm_link_table, "PDMLink", True,
                       "uuid, enovia_part_number, file_title_description, file_name, created_by, creation_date, cad_primary, enovia_revision",
                       records)
        return records

    def _load_pdm(self, connection, table: str, source: str, pdm_link: bool, columns: str,
                  records: list[PdmRecord]) -> None:
        query = sql.SQL("SELECT {} FROM {}").format(
            sql.SQL(columns), sql.Identifier(table))
        with connection.cursor() as cursor:
            cursor.execute(query)
            for row in cursor:
                values = [string(value) for value in row]
                records.append(PdmRecord(*values, source, pdm_link))

    def _load_latest_enovia_records(self, connection) -> list[EnoviaRecord]:
        columns = (
            "uuid, type, part_number, revision, description, cad_primary, project, eol, object_id, "
            "latest_release_rev, latest_rev, state, last_enovia_dash, cad_secondary"
        )
        query = sql.SQL(
            "SELECT {} FROM {} WHERE UPPER(COALESCE(latest_rev, 'YES')) IN ('YES', 'Y', 'TRUE', '1')"
        ).format(sql.SQL(columns), sql.Identifier(self.settings.enovia_table))
        with connection.cursor() as cursor:
            cursor.execute(query)
            return [EnoviaRecord(*(string(value) for value in row)) for row in cursor]

    def _write_report(self, rule: str, report: str, columns: list[str],
                      rows: Iterable[ReportRow]) -> None:
        self.settings.report_directory.mkdir(parents=True, exist_ok=True)
        filename = f"{rule.replace(' ', '-').lower()}-{report}.csv"
        with (self.settings.report_directory / filename).open("w", encoding="utf-8", newline="") as report_file:
            writer = csv.writer(report_file, quoting=csv.QUOTE_ALL)
            writer.writerow(columns)
            writer.writerows([self._value_for(column, row) for column in columns] for row in rows)

    @staticmethod
    def _pdm_link_file_part(record: PdmRecord) -> str:
        return file_stem(record.file_name) if record.pdm_link and not usable(record.parameter_part) else ""

    @staticmethod
    def _pdm_link_base_part(record: PdmRecord) -> str:
        return before_last_underscore(file_stem(record.file_name)) if record.pdm_link and not usable(record.parameter_part) else ""

    @staticmethod
    def _value_for(column: str, row: ReportRow) -> str:
        pdm = row.pdm
        enovia = row.enovia
        values = {
            "pdm.partNumber": pdm.default_part, "pdm.revision": pdm.revision,
            "pdm.description": pdm.description, "pdm.fileName": pdm.file_name,
            "pdm.creator": pdm.creator, "pdm.creationDate": pdm.creation_date,
            "pdm.vault": pdm.vault, "pdm.sourceVault": pdm.vault,
            "matchedVaults": row.matched_vaults,
            "enovia.type": field(enovia, "type"), "enovia.partNumber": field(enovia, "part_number"),
            "enovia.revision": field(enovia, "revision"), "enovia.description": field(enovia, "description"),
            "enovia.cadPrimary": field(enovia, "cad_primary"), "enovia.project": field(enovia, "project"),
            "enovia.eol": field(enovia, "eol"), "enovia.objectId": field(enovia, "object_id"),
            "enovia.latestReleaseRevision": field(enovia, "latest_release_revision"),
            "enovia.latestRevision": field(enovia, "latest_revision"), "enovia.state": field(enovia, "state"),
            "enovia.lastDash": field(enovia, "last_dash"), "enovia.cadSecondary": field(enovia, "cad_secondary"),
        }
        if column not in values:
            raise ValueError(f"Unsupported configured report field: {column}")
        return values[column]


def string(value: object | None) -> str:
    return "" if value is None else str(value).strip()


def field(record: EnoviaRecord | None, name: str) -> str:
    return "" if record is None else getattr(record, name)


def usable(value: str) -> bool:
    return bool(value.strip()) and value.strip().upper() != "NONE"


def normalized(value: str) -> str:
    return value.strip().upper()


def normalized_description(value: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", normalized(value))


def file_stem(value: str) -> str:
    return value.strip().rsplit(".", 1)[0] if "." in value.strip() else value.strip()


def before_last_underscore(value: str) -> str:
    return value.rsplit("_", 1)[0] if "_" in value else value


def part_matches(candidate: str, target: str, match: str) -> bool:
    candidate, target = normalized(candidate), normalized(target)
    return usable(candidate) and (candidate == target if match == "exact" else target.startswith(candidate))


def descriptions_match(left: str, right: str, mode: str) -> bool:
    if mode == "ignore":
        return True
    if mode == "exact":
        return normalized(left) == normalized(right)
    return normalized_description(left) == normalized_description(right)


def main() -> None:
    configuration = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("config") / "application.properties"
    settings = Settings.load(configuration)
    with psycopg.connect(settings.db_url, user=settings.db_user, password=settings.db_password) as connection:
        DataMigrationAnalysisUtility(settings).execute_all_rules(connection)


if __name__ == "__main__":
    main()
