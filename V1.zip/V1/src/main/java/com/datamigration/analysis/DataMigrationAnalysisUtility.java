package com.datamigration.analysis;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.function.Function;
import java.util.function.Predicate;

/**
 * Executes the 15 data-migration matching rules in the order specified by
 * DM_Analysis_Rules_v1.0.xlsx.
 */
public final class DataMigrationAnalysisUtility {
    private final Settings settings;

    private DataMigrationAnalysisUtility(Settings settings) {
        this.settings = settings;
    }

    public static void main(String[] args) throws Exception {
        Path configuration = args.length == 0
                ? Path.of("config", "application.properties")
                : Path.of(args[0]);
        Settings settings = Settings.load(configuration);
        try (Connection connection = DriverManager.getConnection(
                settings.dbUrl(), settings.dbUser(), settings.dbPassword())) {
            connection.setAutoCommit(false);
            DataMigrationAnalysisUtility utility = new DataMigrationAnalysisUtility(settings);
            utility.executeAllRules(connection);
            connection.commit();
        }
    }

    public void executeAllRules(Connection connection) throws SQLException, IOException {
        List<PdmRecord> pdmRecords = loadPdmRecords(connection);
        List<EnoviaRecord> enoviaRecords = loadLatestEnoviaRecords(connection);
        try {
            rule1(connection, pdmRecords, enoviaRecords);
            rule2(connection, pdmRecords, enoviaRecords);
            rule3(connection, pdmRecords, enoviaRecords);
            rule4(connection, pdmRecords, enoviaRecords);
            rule5(connection, pdmRecords, enoviaRecords);
            rule6(connection, pdmRecords, enoviaRecords);
            rule7(connection, pdmRecords, enoviaRecords);
            rule8(connection, pdmRecords, enoviaRecords);
            rule9(connection, pdmRecords, enoviaRecords);
            rule10(connection, pdmRecords, enoviaRecords);
            rule11(connection, pdmRecords, enoviaRecords);
            rule12(connection, pdmRecords, enoviaRecords);
            rule13(connection, pdmRecords, enoviaRecords);
            rule14(connection, pdmRecords, enoviaRecords);
            rule15(connection, pdmRecords, enoviaRecords);
        } catch (SQLException | IOException exception) {
            connection.rollback();
            throw exception;
        }
    }

    /** Rule 1: exact part number and exact description duplicate across vaults. */
    public void rule1(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        duplicateRule(c, "Rule 1", "report-1-duplicates", p, PdmRecord::defaultPart, Match.EXACT);
    }

    /** Rule 2: PDMLink blank part number, filename part and exact description duplicate. */
    public void rule2(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        duplicateRule(c, "Rule 2", "report-2-duplicates", p, this::pdmLinkFilePart, Match.EXACT);
    }

    /** Rule 3: PDMLink filename before last underscore and exact description duplicate. */
    public void rule3(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        duplicateRule(c, "Rule 3", "report-10-duplicates", p, this::pdmLinkBasePart, Match.EXACT);
    }

    /** Rule 4: PDMLink filename before last underscore, prefix part, exact description duplicate. */
    public void rule4(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        duplicateRule(c, "Rule 4", "report-11-duplicates", p, this::pdmLinkBasePart, Match.PREFIX);
    }
	
	
	
    /** Rule 5: exact PDM part number and description match against ENOVIA. */
    public void rule5(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        enoviaRule(c, "Rule 5", "load-sheet-1", p, e, PdmRecord::defaultPart, Match.EXACT, Description.EXACT);
    }

    /** Rule 6: PDM parameter prefix and exact description match against ENOVIA. */
    public void rule6(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        enoviaRule(c, "Rule 6", "report-3", p, e, PdmRecord::parameterPart, Match.PREFIX, Description.EXACT);
    }

    /** Rule 7: PDMLink filename part and exact description match against ENOVIA. */
    public void rule7(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        enoviaRule(c, "Rule 7", "load-sheet-2", p, e, this::pdmLinkFilePart, Match.EXACT, Description.EXACT);
    }

    /** Rule 8: PDMLink filename part prefix and exact description match against ENOVIA. */
    public void rule8(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        enoviaRule(c, "Rule 8", "report-4", p, e, this::pdmLinkFilePart, Match.PREFIX, Description.EXACT);
    }

    /** Rule 9: PDMLink filename-before-underscore and exact description match against ENOVIA. */
    public void rule9(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        enoviaRule(c, "Rule 9", "report-5", p, e, this::pdmLinkBasePart, Match.EXACT, Description.EXACT);
    }

    /** Rule 10: PDMLink filename-before-underscore prefix and exact description ENOVIA match. */
    public void rule10(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        enoviaRule(c, "Rule 10", "report-6", p, e, this::pdmLinkBasePart, Match.PREFIX, Description.EXACT);
    }

    /** Rule 11: probable normalized-description match using a wildcard part number. */
    public void rule11(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        enoviaRule(c, "Rule 11", "report-7", p, e, PdmRecord::defaultPart, Match.PREFIX, Description.NORMALIZED);
    }

    /** Rule 12: wildcard part-number-only probable match against ENOVIA. */
    public void rule12(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        enoviaRule(c, "Rule 12", "report-8", p, e, PdmRecord::defaultPart, Match.PREFIX, Description.IGNORE);
    }

    /** Rule 13: PDMLink filename wildcard duplicate across vaults. */
    public void rule13(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        duplicateRule(c, "Rule 13", "report-9-duplicates", p, this::pdmLinkFilePart, Match.PREFIX);
    }

    /** Rule 14: PDMLink filename-before-underscore exact duplicate across vaults. */
    public void rule14(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        duplicateRule(c, "Rule 14", "report-10-duplicates", p, this::pdmLinkBasePart, Match.EXACT);
    }

    /** Rule 15: PDMLink filename-before-underscore wildcard duplicate across vaults. */
    public void rule15(Connection c, List<PdmRecord> p, List<EnoviaRecord> e) throws SQLException, IOException {
        duplicateRule(c, "Rule 15", "report-11-duplicates", p, this::pdmLinkBasePart, Match.PREFIX);
    }

    private void duplicateRule(Connection connection, String rule, String report, List<PdmRecord> all,
                               Function<PdmRecord, String> part, Match match) throws SQLException, IOException {
        List<PdmRecord> available = unmatched(connection, all);
        List<ReportRow> rows = new ArrayList<>();
        for (PdmRecord record : available) {
            String candidate = part.apply(record);
            if (!usable(candidate)) continue;
            Set<String> vaults = new LinkedHashSet<>();
            for (PdmRecord other : all) {
                if (!record.uuid.equals(other.uuid) && partMatches(candidate, other.defaultPart(), match)
                        && sameDescription(record.description, other.description, Description.EXACT)) {
                    vaults.add(other.vault);
                }
            }
            if (!vaults.isEmpty()) rows.add(new ReportRow(record, null, String.join("|", vaults)));
        }
        persistAndWrite(connection, rule, report, rows, settings.duplicateColumns());
    }

    private void enoviaRule(Connection connection, String rule, String report, List<PdmRecord> all,
                            List<EnoviaRecord> enovia, Function<PdmRecord, String> part,
                            Match match, Description description) throws SQLException, IOException {
        List<ReportRow> rows = new ArrayList<>();
        for (PdmRecord record : unmatched(connection, all)) {
            String candidate = part.apply(record);
            if (!usable(candidate)) continue;
            for (EnoviaRecord target : enovia) {
                if (partMatches(candidate, target.partNumber, match)
                        && sameDescription(record.description, target.description, description)) {
                    rows.add(new ReportRow(record, target, ""));
                }
            }
        }
        persistAndWrite(connection, rule, report, rows, settings.matchColumns());
    }

    private void persistAndWrite(Connection connection, String rule, String report, List<ReportRow> candidates,
                                 List<String> columns) throws SQLException, IOException {
        Map<String, ReportRow> firstMatchPerPdm = new LinkedHashMap<>();
        for (ReportRow row : candidates) firstMatchPerPdm.putIfAbsent(row.pdm.uuid, row);
        Set<String> savedUuids = new LinkedHashSet<>();
        try (PreparedStatement insert = connection.prepareStatement("INSERT INTO " + settings.matchTable()
                + " (uuid, matched_rule, pdm_vault) SELECT ?, ?, ? WHERE NOT EXISTS (SELECT 1 FROM "
                + settings.matchTable() + " WHERE uuid = ?)")) {
            for (ReportRow row : firstMatchPerPdm.values()) {
                insert.setString(1, row.pdm.uuid);
                insert.setString(2, rule);
                insert.setString(3, row.pdm.vault);
                insert.setString(4, row.pdm.uuid);
                if (insert.executeUpdate() == 1) savedUuids.add(row.pdm.uuid);
            }
        }
        writeReport(rule, report, columns,
                candidates.stream().filter(row -> savedUuids.contains(row.pdm.uuid)).toList());
    }

    private List<PdmRecord> unmatched(Connection connection, List<PdmRecord> all) throws SQLException {
        Set<String> matched = new LinkedHashSet<>();
        try (Statement statement = connection.createStatement();
             ResultSet rs = statement.executeQuery("SELECT uuid FROM " + settings.matchTable())) {
            while (rs.next()) matched.add(rs.getString(1));
        }
        return all.stream().filter(record -> !matched.contains(record.uuid)).toList();
    }

    private List<PdmRecord> loadPdmRecords(Connection c) throws SQLException {
        List<PdmRecord> records = new ArrayList<>();
        loadPdm(c, settings.epdmTable(), "EPDM", records,
                "uuid, enovia_part_number, description, file_name, creator, creation_date, cad_primary, enovia_revision",
                false);
        loadPdm(c, settings.pdmLinkTable(), "PDMLink", records,
                "uuid, enovia_part_number, file_title_description, file_name, created_by, creation_date, cad_primary, enovia_revision",
                true);
        return records;
    }

    private void loadPdm(Connection c, String table, String source, List<PdmRecord> records,
                         String columns, boolean pdmLink) throws SQLException {
        try (Statement statement = c.createStatement(); ResultSet rs = statement.executeQuery("SELECT " + columns + " FROM " + table)) {
            while (rs.next()) records.add(new PdmRecord(rs.getString(1), value(rs, 2), value(rs, 3),
                    value(rs, 4), value(rs, 5), value(rs, 6), value(rs, 7), value(rs, 8), source, pdmLink));
        }
    }

    private List<EnoviaRecord> loadLatestEnoviaRecords(Connection c) throws SQLException {
        List<EnoviaRecord> records = new ArrayList<>();
        String sql = "SELECT uuid, type, part_number, revision, description, cad_primary, project, eol, object_id,"
                + " latest_release_rev, latest_rev, state, last_enovia_dash, cad_secondary FROM " + settings.enoviaTable()
                + " WHERE UPPER(COALESCE(latest_rev, 'YES')) IN ('YES', 'Y', 'TRUE', '1')";
        try (Statement statement = c.createStatement(); ResultSet rs = statement.executeQuery(sql)) {
            while (rs.next()) records.add(new EnoviaRecord(value(rs, 1), value(rs, 2), value(rs, 3), value(rs, 4),
                    value(rs, 5), value(rs, 6), value(rs, 7), value(rs, 8), value(rs, 9), value(rs, 10),
                    value(rs, 11), value(rs, 12), value(rs, 13), value(rs, 14)));
        }
        return records;
    }

    private void writeReport(String rule, String report, List<String> columns, List<ReportRow> rows) throws IOException {
        Files.createDirectories(settings.reportDirectory());
        Path file = settings.reportDirectory().resolve(String.format("%s-%s.csv", rule.replace(" ", "-").toLowerCase(Locale.ROOT), report));
        try (BufferedWriter writer = Files.newBufferedWriter(file, StandardCharsets.UTF_8)) {
            writer.write(String.join(",", columns));
            writer.newLine();
            for (ReportRow row : rows) {
                List<String> values = new ArrayList<>();
                for (String column : columns) values.add(csv(valueFor(column.trim(), row)));
                writer.write(String.join(",", values));
                writer.newLine();
            }
        }
    }

    private String valueFor(String column, ReportRow row) {
        PdmRecord p = row.pdm;
        EnoviaRecord e = row.enovia;
        return switch (column) {
            case "pdm.partNumber" -> p.defaultPart(); case "pdm.revision" -> p.revision; case "pdm.description" -> p.description;
            case "pdm.fileName" -> p.fileName; case "pdm.creator" -> p.creator; case "pdm.creationDate" -> p.creationDate;
            case "pdm.vault", "pdm.sourceVault" -> p.vault;
            case "matchedVaults" -> row.matchedVaults;
            case "enovia.type" -> enovia(e, EnoviaRecord::type); case "enovia.partNumber" -> enovia(e, EnoviaRecord::partNumber);
            case "enovia.revision" -> enovia(e, EnoviaRecord::revision); case "enovia.description" -> enovia(e, EnoviaRecord::description);
            case "enovia.cadPrimary" -> enovia(e, EnoviaRecord::cadPrimary); case "enovia.project" -> enovia(e, EnoviaRecord::project);
            case "enovia.eol" -> enovia(e, EnoviaRecord::eol); case "enovia.objectId" -> enovia(e, EnoviaRecord::objectId);
            case "enovia.latestReleaseRevision" -> enovia(e, EnoviaRecord::latestReleaseRevision);
            case "enovia.latestRevision" -> enovia(e, EnoviaRecord::latestRevision); case "enovia.state" -> enovia(e, EnoviaRecord::state);
            case "enovia.lastDash" -> enovia(e, EnoviaRecord::lastDash); case "enovia.cadSecondary" -> enovia(e, EnoviaRecord::cadSecondary);
            default -> throw new IllegalArgumentException("Unsupported configured report field: " + column);
        };
    }

    private String pdmLinkFilePart(PdmRecord record) {
        return record.pdmLink && !usable(record.parameterPart) ? fileStem(record.fileName) : "";
    }

    private String pdmLinkBasePart(PdmRecord record) {
        return record.pdmLink && !usable(record.parameterPart) ? beforeLastUnderscore(fileStem(record.fileName)) : "";
    }

    private static boolean partMatches(String candidate, String target, Match mode) {
        String left = normalize(candidate);
        String right = normalize(target);
        return usable(left) && (mode == Match.EXACT ? left.equals(right) : right.startsWith(left));
    }

    private static boolean sameDescription(String left, String right, Description mode) {
        if (mode == Description.IGNORE) return true;
        return mode == Description.EXACT ? normalize(left).equals(normalize(right))
                : normalizeDescription(left).equals(normalizeDescription(right));
    }

    private static String fileStem(String name) {
        String value = trim(name);
        int dot = value.lastIndexOf('.');
        return dot > 0 ? value.substring(0, dot) : value;
    }

    private static String beforeLastUnderscore(String value) {
        int underscore = value.lastIndexOf('_');
        return underscore > 0 ? value.substring(0, underscore) : value;
    }

    private static String normalize(String value) { return trim(value).toUpperCase(Locale.ROOT); }
    private static String normalizeDescription(String value) { return normalize(value).replaceAll("[^A-Z0-9]", ""); }
    private static boolean usable(String value) { return !trim(value).isEmpty() && !"NONE".equalsIgnoreCase(trim(value)); }
    private static String trim(String value) { return value == null ? "" : value.trim(); }
    private static String value(ResultSet rs, int index) throws SQLException { return trim(rs.getString(index)); }
    private static String csv(String value) { return "\"" + value.replace("\"", "\"\"") + "\""; }
    private static String enovia(EnoviaRecord record, Function<EnoviaRecord, String> field) { return record == null ? "" : field.apply(record); }

    private enum Match { EXACT, PREFIX }
    private enum Description { EXACT, NORMALIZED, IGNORE }
    private record ReportRow(PdmRecord pdm, EnoviaRecord enovia, String matchedVaults) {}
    private record PdmRecord(String uuid, String parameterPart, String description, String fileName, String creator,
                             String creationDate, String vault, String revision, String source, boolean pdmLink) {
        String defaultPart() { return usable(parameterPart) ? parameterPart : fileStem(fileName); }
    }
    private record EnoviaRecord(String uuid, String type, String partNumber, String revision, String description,
                                String cadPrimary, String project, String eol, String objectId,
                                String latestReleaseRevision, String latestRevision, String state,
                                String lastDash, String cadSecondary) {}
    private record Settings(String dbUrl, String dbUser, String dbPassword, String enoviaTable, String epdmTable,
                            String pdmLinkTable, String matchTable, Path reportDirectory,
                            List<String> duplicateColumns, List<String> matchColumns) {
        static Settings load(Path file) throws IOException {
            Properties p = new Properties();
            try (var input = Files.newInputStream(file)) { p.load(input); }
            return new Settings(required(p, "db.url"), required(p, "db.user"), required(p, "db.password"),
                    identifier(p, "table.enovia"), identifier(p, "table.epdm"), identifier(p, "table.pdmLink"),
                    identifier(p, "table.matches"), Path.of(required(p, "reports.directory")),
                    csvList(required(p, "report.columns.duplicate")), csvList(required(p, "report.columns.match")));
        }
        private static String required(Properties p, String key) {
            String value = p.getProperty(key);
            if (value == null || value.isBlank()) throw new IllegalArgumentException("Missing required setting: " + key);
            return value.trim();
        }
        private static String identifier(Properties p, String key) {
            String value = required(p, key);
            if (!value.matches("[A-Za-z_][A-Za-z0-9_]*")) throw new IllegalArgumentException("Invalid SQL identifier in " + key);
            return value;
        }
        private static List<String> csvList(String value) { return Arrays.stream(value.split(",")).map(String::trim).toList(); }
    }
}
