CREATE TABLE IF NOT EXISTS dm_data_match_rules (
    uuid VARCHAR(255) NOT NULL,
    matched_rule VARCHAR(255) NOT NULL,
    pdm_vault VARCHAR(255) NOT NULL,
    PRIMARY KEY (uuid)
);

CREATE INDEX IF NOT EXISTS idx_dm_data_match_rules_rule
    ON dm_data_match_rules (matched_rule);
