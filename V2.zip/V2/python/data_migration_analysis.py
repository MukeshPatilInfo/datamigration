"""Execute the 15 data-migration matching rules defined in DM_Analysis_Rules_v1.0.xlsx."""

from __future__ import annotations

import csv
import re
import sys
from bisect import bisect_left
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable

import psycopg
from psycopg import sql


@dataclass(frozen=True)
class PdmRecord:
    uuid: str
    parameter_part: str
    description: str
    file_name: str
    creator: str
    creation_date: str
    vault: str
    revision: str
    source: str
    pdm_link: bool

    @property
    def default_part(self) -> str:
        return self.parameter_part if usable(self.parameter_part) else file_stem(self.file_name)


@dataclass(frozen=True)
class EnoviaRecord:
    uuid: str
    type: str
    part_number: str
    revision: str
    description: str
    cad_primary: str
    project: str
    eol: str
    object_id: str
    latest_release_revision: str
    latest_revision: str
    state: str
    last_dash: str
    cad_secondary: str


@dataclass(frozen=True)
class ReportRow:
    pdm: PdmRecord
    enovia: EnoviaRecord | None
    matched_vaults: str


@dataclass(frozen=True)
class Settings:
    db_url: str
    db_user: str
    db_password: str
    enovia_table: str
    epdm_table: str
    pdm_link_table: str
    match_table: str
    report_directory: Path
    vaults: list[str]
    duplicate_columns: list[str]
    match_columns: list[str]
    csv_ingestion_enabled: bool
    epdm_csv: Path
    pdm_link_csv: Path
    epdm_malformed_table: str
    pdm_link_malformed_table: str

    @classmethod
    def load(cls, path: Path) -> Settings:
        values: dict[str, str] = {}
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                key, separator, value = line.partition("=")
                if not separator:
                    raise ValueError(f"Invalid configuration line: {line}")
                values[key.strip()] = value.strip()

        def required(key: str) -> str:
            value = values.get(key, "")
            if not value:
                raise ValueError(f"Missing required setting: {key}")
            return value

        def table(key: str) -> str:
            value = required(key)
            if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
                raise ValueError(f"Invalid SQL identifier in {key}")
            return value

        def columns(key: str) -> list[str]:
            return [column.strip() for column in required(key).split(",")]

        return cls(
            required("db.url"),
            required("db.user"),
            required("db.password"),
            table("table.enovia"),
            table("table.epdm"),
            table("table.pdmLink"),
            table("table.matches"),
            Path(required("reports.directory")),
            columns("report.vaults"),
            columns("report.columns.duplicate"),
            columns("report.columns.match"),
            values.get("csv.ingestion.enabled", "false").lower() == "true",
            Path(required("csv.epdm.path")),
            Path(required("csv.pdmLink.path")),
            table("table.epdmMalformed"),
            table("table.pdmLinkMalformed"),
        )


class DataMigrationAnalysisUtility:
    """Runs each spreadsheet rule in order and excludes previously matched PDM UUIDs."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def execute_all_rules(self, connection: psycopg.Connection) -> None:
        pdm_records = self._load_pdm_records(connection)
        enovia_records = self._load_latest_enovia_records(connection)
        self.rule1(connection, pdm_records, enovia_records)
        self.rule2(connection, pdm_records, enovia_records)
        self.rule3(connection, pdm_records, enovia_records)
        self.rule4(connection, pdm_records, enovia_records)
        self.rule5(connection, pdm_records, enovia_records)
        self.rule6(connection, pdm_records, enovia_records)
        self.rule7(connection, pdm_records, enovia_records)
        self.rule8(connection, pdm_records, enovia_records)
        self.rule9(connection, pdm_records, enovia_records)
        self.rule10(connection, pdm_records, enovia_records)
        self.rule11(connection, pdm_records, enovia_records)
        self.rule12(connection, pdm_records, enovia_records)
        self.rule13(connection, pdm_records, enovia_records)
        self.rule14(connection, pdm_records, enovia_records)
        self.rule15(connection, pdm_records, enovia_records)

    # Rule 1: exact part number and exact description duplicates across vaults.
    def rule1(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 1", "report-1-duplicates", pdm,
                             lambda record: record.default_part, "exact")

    # Rule 2: PDMLink blank part number, filename part and exact description duplicates.
    def rule2(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 2", "report-2-duplicates", pdm,
                             self._pdm_link_file_part, "exact")

    # Rule 3: PDMLink filename before the last underscore and exact description duplicates.
    def rule3(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 3", "report-10-duplicates", pdm,
                             self._pdm_link_base_part, "exact")

    # Rule 4: PDMLink filename base prefix and exact description duplicates.
    def rule4(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 4", "report-11-duplicates", pdm,
                             self._pdm_link_base_part, "prefix")

    # Rule 5: exact PDM part number and description match against ENOVIA.
    def rule5(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 5", "load-sheet-1", pdm, enovia,
                          lambda record: record.default_part, "exact", "exact")

    # Rule 6: PDM parameter prefix and exact description match against ENOVIA.
    def rule6(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 6", "report-3", pdm, enovia,
                          lambda record: record.parameter_part, "prefix", "exact")

    # Rule 7: PDMLink filename part and exact description match against ENOVIA.
    def rule7(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 7", "load-sheet-2", pdm, enovia,
                          self._pdm_link_file_part, "exact", "exact")

    # Rule 8: PDMLink filename part prefix and exact description match against ENOVIA.
    def rule8(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 8", "report-4", pdm, enovia,
                          self._pdm_link_file_part, "prefix", "exact")

    # Rule 9: PDMLink filename base and exact description match against ENOVIA.
    def rule9(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 9", "report-5", pdm, enovia,
                          self._pdm_link_base_part, "exact", "exact")

    # Rule 10: PDMLink filename base prefix and exact description match against ENOVIA.
    def rule10(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 10", "report-6", pdm, enovia,
                          self._pdm_link_base_part, "prefix", "exact")

    # Rule 11: wildcard part number with normalized probable-description matching.
    def rule11(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 11", "report-7", pdm, enovia,
                          lambda record: record.default_part, "prefix", "normalized")

    # Rule 12: wildcard part number only, without a description condition.
    def rule12(self, connection, pdm, enovia) -> None:
        self._enovia_rule(connection, "Rule 12", "report-8", pdm, enovia,
                          lambda record: record.default_part, "prefix", "ignore")

    # Rule 13: PDMLink filename wildcard duplicates across vaults.
    def rule13(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 13", "report-9-duplicates", pdm,
                             self._pdm_link_file_part, "prefix")

    # Rule 14: PDMLink filename base exact duplicates across vaults.
    def rule14(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 14", "report-10-duplicates", pdm,
                             self._pdm_link_base_part, "exact")

    # Rule 15: PDMLink filename base wildcard duplicates across vaults.
    def rule15(self, connection, pdm, enovia) -> None:
        self._duplicate_rule(connection, "Rule 15", "report-11-duplicates", pdm,
                             self._pdm_link_base_part, "prefix")

    def _duplicate_rule(self, connection, rule: str, report: str, all_records: list[PdmRecord],
                        part: Callable[[PdmRecord], str], match: str) -> None:
        exact_matches = (
            group_by(all_records, lambda record: part_description_key(record.default_part, record.description))
            if match == "exact" else {}
        )
        prefix_matches = group_pdm_by_description_and_part(all_records) if match == "prefix" else {}
        rows: list[ReportRow] = []
        for record in self._unmatched(connection, all_records):
            candidate = part(record)
            if not usable(candidate):
                continue
            possible_matches = (
                exact_matches.get(part_description_key(candidate, record.description), [])
                if match == "exact"
                else matching_pdm_part_prefix(prefix_matches.get(normalized(record.description), []), candidate)
            )
            vaults = {
                other.vault for other in possible_matches
                if other.uuid != record.uuid
                and part_matches(candidate, other.default_part, match)
            }
            if vaults:
                rows.append(ReportRow(record, None, "|".join(sorted(vaults))))
        self._persist_and_write(connection, rule, report, rows, self.settings.duplicate_columns)

    def _enovia_rule(self, connection, rule: str, report: str, all_records: list[PdmRecord],
                     enovia_records: list[EnoviaRecord], part: Callable[[PdmRecord], str],
                     match: str, description: str) -> None:
        records_by_description = (
            {} if description == "ignore" else group_by(
                enovia_records, lambda record: normalized(record.description)
                if description == "exact" else normalized_description(record.description))
        )
        records_by_part = sorted(
            ((normalized(record.part_number), record) for record in enovia_records),
            key=lambda item: item[0],
        )
        rows: list[ReportRow] = []
        for record in self._unmatched(connection, all_records):
            candidate = part(record)
            if not usable(candidate):
                continue
            if description == "ignore":
                targets = matching_part_prefix(records_by_part, candidate)
            else:
                key = (normalized(record.description) if description == "exact"
                       else normalized_description(record.description))
                targets = records_by_description.get(key, [])
            for target in targets:
                if (part_matches(candidate, target.part_number, match)
                        and descriptions_match(record.description, target.description, description)):
                    rows.append(ReportRow(record, target, ""))
        self._persist_and_write(connection, rule, report, rows, self.settings.match_columns)

    def _persist_and_write(self, connection, rule: str, report: str, candidates: list[ReportRow],
                           columns: list[str]) -> None:
        first_match = {row.pdm.uuid: row for row in candidates}
        inserted_uuids: set[str] = set()
        query = sql.SQL(
            "INSERT INTO {} (uuid, matched_rule, pdm_vault) "
            "SELECT %s, %s, %s WHERE NOT EXISTS (SELECT 1 FROM {} WHERE uuid = %s)"
        ).format(sql.Identifier(self.settings.match_table), sql.Identifier(self.settings.match_table))
        with connection.cursor() as cursor:
            for row in first_match.values():
                cursor.execute(query, (row.pdm.uuid, rule, row.pdm.vault, row.pdm.uuid))
                if cursor.rowcount == 1:
                    inserted_uuids.add(row.pdm.uuid)
        self._write_report(rule, report, columns,
                           (row for row in candidates if row.pdm.uuid in inserted_uuids))

    def _unmatched(self, connection, records: list[PdmRecord]) -> list[PdmRecord]:
        query = sql.SQL("SELECT uuid FROM {}").format(sql.Identifier(self.settings.match_table))
        with connection.cursor() as cursor:
            cursor.execute(query)
            matched = {str(row[0]) for row in cursor}
        return [record for record in records if record.uuid not in matched]

    def _load_pdm_records(self, connection) -> list[PdmRecord]:
        records: list[PdmRecord] = []
        self._load_pdm(connection, self.settings.epdm_table, "EPDM", False,
                       "uuid, enovia_part_number, description, file_name, creator, creation_date, cad_primary, enovia_revision",
                       records)
        self._load_pdm(connection, self.settings.pdm_link_table, "PDMLink", True,
                       "uuid, enovia_part_number, file_title_description, file_name, created_by, creation_date, cad_primary, enovia_revision",
                       records)
        return records

    def _load_pdm(self, connection, table: str, source: str, pdm_link: bool, columns: str,
                  records: list[PdmRecord]) -> None:
        query = sql.SQL("SELECT {} FROM {}").format(
            sql.SQL(columns), sql.Identifier(table))
        with connection.cursor() as cursor:
            cursor.execute(query)
            for row in cursor:
                values = [string(value) for value in row]
                records.append(PdmRecord(*values, source, pdm_link))

    def _load_latest_enovia_records(self, connection) -> list[EnoviaRecord]:
        columns = (
            "uuid, type, part_number, revision, description, cad_primary, project, eol, object_id, "
            "latest_release_rev, latest_rev, state, last_enovia_dash, cad_secondary"
        )
        query = sql.SQL(
            "SELECT {} FROM {} WHERE UPPER(COALESCE(latest_rev, 'YES')) IN ('YES', 'Y', 'TRUE', '1')"
        ).format(sql.SQL(columns), sql.Identifier(self.settings.enovia_table))
        with connection.cursor() as cursor:
            cursor.execute(query)
            return [EnoviaRecord(*(string(value) for value in row)) for row in cursor]

    def _write_report(self, rule: str, report: str, columns: list[str],
                      rows: Iterable[ReportRow]) -> None:
        self.settings.report_directory.mkdir(parents=True, exist_ok=True)
        rows_by_vault: dict[str, list[ReportRow]] = {vault: [] for vault in self.settings.vaults}
        for row in rows:
            rows_by_vault.setdefault(row.pdm.vault, []).append(row)
        for vault, vault_rows in rows_by_vault.items():
            filename = f"{rule.replace(' ', '-').lower()}-{report}-{vault}.csv"
            with (self.settings.report_directory / filename).open("w", encoding="utf-8", newline="") as report_file:
                writer = csv.writer(report_file, quoting=csv.QUOTE_ALL)
                writer.writerow(columns)
                writer.writerows([self._value_for(column, row) for column in columns] for row in vault_rows)

    @staticmethod
    def _pdm_link_file_part(record: PdmRecord) -> str:
        return file_stem(record.file_name) if record.pdm_link and not usable(record.parameter_part) else ""

    @staticmethod
    def _pdm_link_base_part(record: PdmRecord) -> str:
        return before_last_underscore(file_stem(record.file_name)) if record.pdm_link and not usable(record.parameter_part) else ""

    @staticmethod
    def _value_for(column: str, row: ReportRow) -> str:
        pdm = row.pdm
        enovia = row.enovia
        values = {
            "pdm.partNumber": pdm.default_part, "pdm.revision": pdm.revision,
            "pdm.description": pdm.description, "pdm.fileName": pdm.file_name,
            "pdm.creator": pdm.creator, "pdm.creationDate": pdm.creation_date,
            "pdm.vault": pdm.vault, "pdm.sourceVault": pdm.vault,
            "matchedVaults": row.matched_vaults,
            "enovia.type": field(enovia, "type"), "enovia.partNumber": field(enovia, "part_number"),
            "enovia.revision": field(enovia, "revision"), "enovia.description": field(enovia, "description"),
            "enovia.cadPrimary": field(enovia, "cad_primary"), "enovia.project": field(enovia, "project"),
            "enovia.eol": field(enovia, "eol"), "enovia.objectId": field(enovia, "object_id"),
            "enovia.latestReleaseRevision": field(enovia, "latest_release_revision"),
            "enovia.latestRevision": field(enovia, "latest_revision"), "enovia.state": field(enovia, "state"),
            "enovia.lastDash": field(enovia, "last_dash"), "enovia.cadSecondary": field(enovia, "cad_secondary"),
        }
        if column not in values:
            raise ValueError(f"Unsupported configured report field: {column}")
        return values[column]


def string(value: object | None) -> str:
    return "" if value is None else str(value).strip()


def field(record: EnoviaRecord | None, name: str) -> str:
    return "" if record is None else getattr(record, name)


def usable(value: str) -> bool:
    return bool(value.strip()) and value.strip().upper() != "NONE"


def normalized(value: str) -> str:
    return value.strip().upper()


def normalized_description(value: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", normalized(value))


def file_stem(value: str) -> str:
    return value.strip().rsplit(".", 1)[0] if "." in value.strip() else value.strip()


def before_last_underscore(value: str) -> str:
    return value.rsplit("_", 1)[0] if "_" in value else value


def part_matches(candidate: str, target: str, match: str) -> bool:
    candidate, target = normalized(candidate), normalized(target)
    return usable(candidate) and (candidate == target if match == "exact" else target.startswith(candidate))


def descriptions_match(left: str, right: str, mode: str) -> bool:
    if mode == "ignore":
        return True
    if mode == "exact":
        return normalized(left) == normalized(right)
    return normalized_description(left) == normalized_description(right)


def group_by(records: Iterable, key: Callable) -> dict[str, list]:
    grouped: dict[str, list] = {}
    for record in records:
        grouped.setdefault(key(record), []).append(record)
    return grouped


def matching_part_prefix(records: list[tuple[str, EnoviaRecord]], candidate: str) -> Iterable[EnoviaRecord]:
    candidate = normalized(candidate)
    index = bisect_left(records, (candidate,))
    while index < len(records) and records[index][0].startswith(candidate):
        yield records[index][1]
        index += 1


def group_pdm_by_description_and_part(records: Iterable[PdmRecord]) -> dict[str, list[tuple[str, PdmRecord]]]:
    grouped: dict[str, list[tuple[str, PdmRecord]]] = {}
    for record in records:
        grouped.setdefault(normalized(record.description), []).append((normalized(record.default_part), record))
    for part_records in grouped.values():
        part_records.sort(key=lambda item: item[0])
    return grouped


def matching_pdm_part_prefix(records: list[tuple[str, PdmRecord]], candidate: str) -> Iterable[PdmRecord]:
    candidate = normalized(candidate)
    index = bisect_left(records, (candidate,))
    while index < len(records) and records[index][0].startswith(candidate):
        yield records[index][1]
        index += 1


def part_description_key(part: str, description: str) -> str:
    return f"{normalized(part)}\0{normalized(description)}"


def ingest_pdm_csv(connection: psycopg.Connection, settings: Settings) -> None:
    """Load valid PDM CSV rows and quarantine malformed physical rows."""
    if not settings.csv_ingestion_enabled:
        return
    create_reject_table(connection, settings.epdm_table, settings.epdm_malformed_table)
    create_reject_table(connection, settings.pdm_link_table, settings.pdm_link_malformed_table)
    load_csv(connection, settings.epdm_csv, settings.epdm_table, settings.epdm_malformed_table, False, 8,
             ("enovia_part_number", "description", "file_name", "creator", "creation_date", "cad_primary", "enovia_revision"),
             lambda row: (row[1], row[2], row[3], row[4], row[5], row[6], row[7]))
    load_csv(connection, settings.pdm_link_csv, settings.pdm_link_table, settings.pdm_link_malformed_table, True, 11,
             ("enovia_part_number", "file_title_description", "file_name", "created_by", "creation_date", "cad_primary", "enovia_revision"),
             lambda row: (row[1], row[2], row[3], row[4], row[6], row[7], row[8]))


def create_reject_table(connection, source: str, reject: str) -> None:
    with connection.cursor() as cursor:
        cursor.execute(sql.SQL("CREATE TABLE IF NOT EXISTS {} (LIKE {} INCLUDING DEFAULTS)").format(
            sql.Identifier(reject), sql.Identifier(source)))
        cursor.execute(sql.SQL("ALTER TABLE {} ADD COLUMN IF NOT EXISTS raw_csv_row TEXT").format(sql.Identifier(reject)))
        cursor.execute(sql.SQL("ALTER TABLE {} ADD COLUMN IF NOT EXISTS reject_reason TEXT").format(sql.Identifier(reject)))


def load_csv(connection, path: Path, target: str, reject: str, has_header: bool, expected_columns: int,
             columns: tuple[str, ...], mapper: Callable[[list[str]], tuple[str, ...]]) -> None:
    target_columns = sql.SQL(", ").join(sql.Identifier(column) for column in columns)
    placeholders = sql.SQL(", ").join(sql.Placeholder() for _ in columns)
    valid_query = sql.SQL("INSERT INTO {} ({}) VALUES ({})").format(sql.Identifier(target), target_columns, placeholders)
    reject_query = sql.SQL("INSERT INTO {} (raw_csv_row, reject_reason) VALUES (%s, %s)").format(sql.Identifier(reject))
    with path.open(encoding="utf-8", newline="") as source, connection.cursor() as cursor:
        for number, raw in enumerate(source, 1):
            if has_header and number == 1:
                continue
            row, reason = parse_csv_physical_row(raw.rstrip("\r\n"))
            if reason is None and len(row) == expected_columns:
                cursor.execute(valid_query, mapper(row))
            else:
                cursor.execute(reject_query, (raw.rstrip("\r\n"), reason or f"Expected {expected_columns} columns; found {len(row)}"))


def parse_csv_physical_row(raw: str) -> tuple[list[str], str | None]:
    fields, field, quoted, started = [], [], False, False
    index = 0
    while index < len(raw):
        character = raw[index]
        if character == '"':
            if not started:
                quoted, started = True, True
            elif quoted and index + 1 < len(raw) and raw[index + 1] == '"':
                field.append(character)
                index += 1
            elif quoted:
                quoted = False
            else:
                return fields, "Unexpected quote"
        elif character == "," and not quoted:
            fields.append("".join(field))
            field, started = [], False
        else:
            field.append(character)
            started = True
        index += 1
    if quoted:
        return fields, "Unterminated quoted field"
    fields.append("".join(field))
    return fields, None


def main() -> None:
    configuration = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("config") / "application.properties"
    settings = Settings.load(configuration)
    database_url = settings.db_url.removeprefix("jdbc:")
    with psycopg.connect(database_url, user=settings.db_user, password=settings.db_password) as connection:
        ingest_pdm_csv(connection, settings)
        DataMigrationAnalysisUtility(settings).execute_all_rules(connection)


if __name__ == "__main__":
    main()
