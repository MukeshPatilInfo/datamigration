# Data Migration Analysis Utility

Configure the database connection, table names, report directory, and output columns in
`config\application.properties`. Run `sql\001_create_match_tracking.sql` once after the source
tables have been created.

Build and run:

```powershell
mvn package
java -jar target\data-migration-analysis-utility-1.0.0.jar config\application.properties
```

The utility executes Rules 1 through 15 in spreadsheet order. A PDM record is inserted into
`dm_data_match_rules` as soon as it is reported, so it is excluded from every later rule and
report. CSV reports are written below `reports.directory`.
Each rule writes a separate CSV for every vault listed in `report.vaults`; `cad_primary` from
each PDM source table is used as that record's vault.

## Python implementation

The Python utility uses the same configuration file, output columns, SQL table names, and matching
sequence as the Java version.

```powershell
py -m pip install -r python\requirements.txt
py python\data_migration_analysis.py config\application.properties
```
