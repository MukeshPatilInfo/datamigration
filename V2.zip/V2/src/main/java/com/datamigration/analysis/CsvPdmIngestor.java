package com.datamigration.analysis;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

final class CsvPdmIngestor {
    private CsvPdmIngestor() {}

    static void ingest(Connection connection, DataMigrationAnalysisUtility.Settings settings)
            throws SQLException, IOException {
        if (!settings.csvIngestionEnabled()) return;
        createRejectTable(connection, settings.epdmTable(), settings.epdmMalformedTable());
        createRejectTable(connection, settings.pdmLinkTable(), settings.pdmLinkMalformedTable());
        loadEpdm(connection, settings.epdmCsv(), settings.epdmTable(), settings.epdmMalformedTable());
        loadPdmLink(connection, settings.pdmLinkCsv(), settings.pdmLinkTable(), settings.pdmLinkMalformedTable());
    }

    private static void createRejectTable(Connection c, String source, String reject) throws SQLException {
        try (Statement statement = c.createStatement()) {
            statement.execute("CREATE TABLE IF NOT EXISTS " + reject + " (LIKE " + source + " INCLUDING DEFAULTS)");
            statement.execute("ALTER TABLE " + reject + " ADD COLUMN IF NOT EXISTS raw_csv_row TEXT");
            statement.execute("ALTER TABLE " + reject + " ADD COLUMN IF NOT EXISTS reject_reason TEXT");
        }
    }

    private static void loadEpdm(Connection c, Path file, String target, String reject) throws IOException, SQLException {
        load(c, file, target, reject, false, 8,
                "enovia_part_number, description, file_name, creator, creation_date, cad_primary, enovia_revision",
                row -> List.of(row.get(1), row.get(2), row.get(3), row.get(4), row.get(5), row.get(6), row.get(7)));
    }

    private static void loadPdmLink(Connection c, Path file, String target, String reject) throws IOException, SQLException {
        load(c, file, target, reject, true, 11,
                "enovia_part_number, file_title_description, file_name, created_by, creation_date, cad_primary, enovia_revision",
                row -> List.of(row.get(1), row.get(2), row.get(3), row.get(4), row.get(6), row.get(7), row.get(8)));
    }

    private static void load(Connection c, Path file, String target, String reject, boolean hasHeader, int columns,
                             String targetColumns, RowMapper mapper) throws IOException, SQLException {
        String placeholders = String.join(",", java.util.Collections.nCopies(targetColumns.split(",").length, "?"));
        try (BufferedReader reader = Files.newBufferedReader(file);
             PreparedStatement valid = c.prepareStatement("INSERT INTO " + target + " (" + targetColumns + ") VALUES (" + placeholders + ")");
             PreparedStatement invalid = c.prepareStatement("INSERT INTO " + reject + " (raw_csv_row, reject_reason) VALUES (?, ?)")) {
            String raw;
            long line = 0;
            while ((raw = reader.readLine()) != null) {
                line++;
                if (hasHeader && line == 1) continue;
                Parsed parsed = parse(raw);
                if (parsed.error != null || parsed.fields.size() != columns) {
                    invalid.setString(1, raw);
                    invalid.setString(2, parsed.error != null ? parsed.error : "Expected " + columns + " columns; found " + parsed.fields.size());
                    invalid.addBatch();
                } else {
                    List<String> values = mapper.map(parsed.fields);
                    for (int i = 0; i < values.size(); i++) valid.setString(i + 1, values.get(i));
                    valid.addBatch();
                }
                if (line % 1_000 == 0) { valid.executeBatch(); invalid.executeBatch(); }
            }
            valid.executeBatch();
            invalid.executeBatch();
        }
    }

    private static Parsed parse(String raw) {
        List<String> fields = new ArrayList<>();
        StringBuilder field = new StringBuilder();
        boolean quoted = false;
        boolean fieldStarted = false;
        for (int i = 0; i < raw.length(); i++) {
            char ch = raw.charAt(i);
            if (ch == '"') {
                if (!fieldStarted) { quoted = true; fieldStarted = true; }
                else if (quoted && i + 1 < raw.length() && raw.charAt(i + 1) == '"') { field.append(ch); i++; }
                else if (quoted) quoted = false;
                else return new Parsed(fields, "Unexpected quote");
            } else if (ch == ',' && !quoted) { fields.add(field.toString()); field.setLength(0); fieldStarted = false; }
            else { field.append(ch); fieldStarted = true; }
        }
        if (quoted) return new Parsed(fields, "Unterminated quoted field");
        fields.add(field.toString());
        return new Parsed(fields, null);
    }

    private record Parsed(List<String> fields, String error) {}
    private interface RowMapper { List<String> map(List<String> row); }
}
